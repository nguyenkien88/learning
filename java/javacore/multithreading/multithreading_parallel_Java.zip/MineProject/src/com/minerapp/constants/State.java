package com.minerapp.constants;

public enum State {
	EMPTY, MINE, MINESWEEPER, MINELAYER;
}
